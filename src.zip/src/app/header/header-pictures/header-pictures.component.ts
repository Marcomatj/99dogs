import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dogs-header-pictures',
  templateUrl: './header-pictures.component.html',
  styleUrls: ['./header-pictures.component.css']
})
export class HeaderPicturesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
